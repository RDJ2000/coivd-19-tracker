import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, Input } from "@angular/core";
import { ModalController } from '@ionic/angular';
import { countries } from '../../assets/data/countries';
import {  AptService } from '../apt.service'; 
import { Chart } from 'chart.js';
import { CountrymodelPageModule } from '../countrymodel/countrymodel.module';
import { CountrymodelPage } from '../countrymodel/countrymodel.page';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})

export class HomePage implements AfterViewInit{
  @ViewChild("barCanvas",{static:true}) barCanvas: ElementRef;

  
  private barChart: Chart;

  constructor(private aptService: AptService,public modalController: ModalController,public toastController: ToastController) {this.init();this.presentToast()}

  ngAfterViewInit() {
    setTimeout(()=>{
      this.ionchart();
      this.ionhbarchart();
      this.ionbarchart();
      this.ionpolarchart();
    },1000);
  }

  menu:any[]=countries;
  selected_country:string;
 
  mydata:string;
  countryname:string;
  TC:number;
  TD:number;
  TR:number;
  data:any;
 //toast
 async presentToast() {
  const toast = await this.toastController.create({
    message: "This Application is fetching data from open-source API ,Therefore sometime data Doesn't load in go. PRESS reload if this happens!",
    duration: 5000
  });
  toast.present();
}

  //Model
  async openModal() {
    const modal = await this.modalController.create({
      component: CountrymodelPage,
      componentProps: {
        "selected_country":this.selected_country
      }
    });
 
    modal.onDidDismiss().then((dataReturned) => {
   
    });
 
    return await modal.present();
  }

//globalchart
    ionchart(){
      
      var canvas : any = document.getElementById("myChart");
      var ctx = canvas.getContext("2d");
     
      var myChart = new Chart(ctx, {
          type: 'doughnut',
          data: {
              labels: ['Total Confirmed','Recovered','Death'  ],
              datasets: [{
                  label: 'Covid-19 chart',
                  data: [this.TC, this.TR,this.TD],
                  weight:2,
                  order:1,
                  backgroundColor: [
                    'rgba(255, 255, 74, 1)',
                    ' #99FF33', 
                      '#FF3333', 
                     
                           
                  ],
                  borderColor: [
                    '#FFFF',
                    '#FFFF',
                    '#ffff'
                    
                     
                    
                  ],
                  borderWidth: 2
              },]
          },
          options: {
            rotation: 1 * Math.PI,
            circumference: 1 * Math.PI,
            
            responsive: true,
            legend: { position: 'left',},
            title: { display: true, text: 'Doughnut Chart' },
            animation: { animateScale: true, animateRotate: true },
      
            cutoutPercentage: 70
        }
          
      });
      
    
  }
  //global Bar chart

  ionbarchart(){
    var canvas : any = document.getElementById("mybarChart");
    var ctx = canvas.getContext("2d");
   
    var myChart = new Chart(ctx, {
      type:'radar',
      data: {
        labels: ['Total-Confirmed', 'Total-Deaths', 'Total-Recovered'],
        datasets: [{
          label:'Radar Chart',
            data: [this.TC,this.TD,this.TR],
            backgroundColor:['rgba(255, 255, 74, 1) ','#FF3333',' #99FF33', ],
            fill:'#00ff00'
        }]
    },options:{
      
      legend: { display: false },
    title:{display:true,text:"Radar Chart"},
      responsive: true,
    }
    });

  }

  //polarchart
  ionpolarchart(){
    var canvas : any = document.getElementById("mypolarChart");
    var ctx = canvas.getContext("2d");
   
    var myChart = new Chart(ctx, {
      type:'polarArea',
      data: {
        labels: ['Total-Confirmed', 'Total-Deaths', 'Total-Recovered'],
        datasets: [{
          label:'Polar Chart',
            data: [this.TC,this.TD,this.TR],
            backgroundColor:['rgba(255, 255, 74, 1) ','#FF3333',' #99FF33', ],
            fill:'#00ff00'
        }]
    },options:{
      legend:{position:"right"},
      title:{display:true,text:"Polar Chart"},
      responsive: true,
    }
    });

  }

//horizontal bar
ionhbarchart(){
  var canvas : any = document.getElementById("myhbarChart");
  var ctx = canvas.getContext("2d");
 
  var myChart = new Chart(ctx, {
    type:'horizontalBar',
    data: {
      labels: ['Total-Confirmed', 'Total-Deaths', 'Total-Recovered'],
      datasets: [{
        label:'Horizontal-bar',
          data: [this.TC,this.TD,this.TR],
          backgroundColor:['rgba(255, 255, 74, 1) ','#FF3333',' #99FF33', ],
          
      }]
  },options:{
    legend: { display: false },
    title:{display:true,text:"Horizontal-Bar Chart"},
    responsive: true,
  }
  });

}
  //Global api call
  
init(){
  this.ngAfterViewInit();
  
    this.aptService.getglobal().toPromise().then((response) => {

     
      
      this.mydata=JSON.stringify(Object(response));
      this.data=JSON.parse(this.mydata);
      let  gdata=this.data;
      

      
      this.TC=gdata.Global.TotalConfirmed;
      this.TD=gdata.Global.TotalDeaths;
      this.TR=gdata.Global.TotalRecovered;  


    }).catch((err) => {
      console.warn(err);
    });
    


}

}