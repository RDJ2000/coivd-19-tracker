import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { countries } from 'src/assets/data/countries';

 
const httpOptions = {
  headers: new HttpHeaders({
    
    'Accept': 'application/json'
  })
};



@Injectable({
  providedIn: 'root'
})
export class AptService {
  selected_country:string;
  url="https://api.covid19api.com/summary";
  gurl="https://api.covid19api.com/dayone/country/";
 
 
 
  constructor(private http: HttpClient) { }
 
  getglobal() {
   return this.http.get<any>(this.url);
  }


  getcountry(){
    
    console.log(this.selected_country);
    return this.http.get<any>(this.gurl+this.selected_country);

  }


  getvalue(CountryName:string){
  this.selected_country=CountryName;
  console.log(this.selected_country);
  }

}
