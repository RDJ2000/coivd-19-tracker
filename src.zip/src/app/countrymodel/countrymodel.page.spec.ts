import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { CountrymodelPage } from './countrymodel.page';

describe('CountrymodelPage', () => {
  let component: CountrymodelPage;
  let fixture: ComponentFixture<CountrymodelPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CountrymodelPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(CountrymodelPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
