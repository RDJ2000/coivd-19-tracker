import { Component, OnInit } from '@angular/core';
import {ModalController,NavParams} from '@ionic/angular';
import {  AptService } from '../apt.service';
import { from } from 'rxjs';
import {ReversePipe} from './reverse'
import * as Chart from 'chart.js';


@Component({
  selector: 'app-countrymodel',
  templateUrl: './countrymodel.page.html',
  styleUrls: ['./countrymodel.page.scss'],
})
export class CountrymodelPage implements OnInit {
  

  CountryName:string;
  TotalConfirmed:Array<any>;
  TotalDeaths:Array<any>;
  TotalRecovered: Array<any>;
  mydata:any;
  data:string;
  TotalActive:Array<any>;
  dates:Array<any>;


  constructor(private modalController: ModalController,
    private navParams: NavParams,private aptService: AptService) { 
      
      this.ngOnInit();
  }

  ngOnInit() {
    
    this.CountryName=this.navParams.data.selected_country;
    this.aptService.getvalue(this.CountryName);
    this.countryCall();
  }
  ngAfterViewInit() {
    setTimeout(()=>{
      this.ionbarchart();
      this.ionlinechart();
    },3000);
  }

  ionlinechart(){
    var canvas : any = document.getElementById("mylineChart");
    var ctx = canvas.getContext("2d");
   
    var myChart = new Chart(ctx, {
      type:'line',
      data: {
        labels: this.dates,
        datasets: [{
          label:'Total-Confirmed',
            data:this.TotalConfirmed,
            borderColor:['#fffb00'],
            fill:false
            
        },{
          label:'Total-Active',
          data:this.TotalActive,
          borderColor:['#ff8700'],
          fill:false
        },{
          label:'Total-Recovered',
          data:this.TotalRecovered,
          borderColor:['#00ff00'],
          fill:false
        },{
          label:'Total-Deaths',
          data:this.TotalDeaths,
          borderColor:['#ff2d00'],
          fill:false
        }]
    },options:{
      legend:{position:"bottom"},
      responsive: true,
    }
    });
  }

  //Bar Chart
  ionbarchart(){
    var canvas : any = document.getElementById("mybar_Chart");
    var ctx = canvas.getContext("2d");
    
    var myChart = new Chart(ctx, {
      type:'bar',
      data: {
        labels: this.dates,
        datasets: [{
         
        label:'Total-Deaths',
        barPercentage: 0.5,
      barThickness: 6,
      maxBarThickness: 8,
      minBarLength: 2, 
      
      backgroundColor:'#ff2d00',
      data: this.TotalDeaths

        },{
          label:'Total-Recovered',
          barPercentage: 0.5,
        barThickness: 6,
        maxBarThickness: 8,
        minBarLength: 2,
        backgroundColor:'#00ff00',
        data: this.TotalRecovered
        },{
          
        label:'Total-Active',
          barPercentage: 0.5,
        barThickness: 6,
        maxBarThickness: 8,
        minBarLength: 2,
        data: this.TotalActive,
        backgroundColor:'#ff8700',
        },{
          label:'Total-Confirmed',
          barPercentage: 0.5,
        barThickness: 6,
        maxBarThickness: 8,
        minBarLength: 2,  
        data: this.TotalConfirmed,
        backgroundColor:'#fffb00',
        }]
    },options:{
      legend:{position:"bottom"},
      responsive: true,
    }
    });
  }

  //close modal
  async closeModal() {
    const onClosedData: string = "Wrapped Up!";
    await this.modalController.dismiss(onClosedData);
  }
//Api call

countryCall(){
  
 
  this.aptService.getcountry().toPromise().then((response) => {

     this.dates=response.map((date: { Date: any; })=>{return date.Date;})
     
     this.TotalConfirmed=response.map((data: { Confirmed: any; })=>{return data.Confirmed;})
     this.TotalRecovered=response.map((data: { Recovered: any; })=>{return data.Recovered;})
     this.TotalDeaths=response.map((data: { Deaths: any; })=>{return data.Deaths;})
     this.TotalActive=response.map((data: { Active: any; })=>{return data.Active;})
      
    this.mydata=JSON.stringify(Object(response));
    this.data=JSON.parse(this.mydata);
    let  gdata=this.data;
    
     

  }).catch((err) => {
    console.warn(err);
  });
  


}
//line chat


}