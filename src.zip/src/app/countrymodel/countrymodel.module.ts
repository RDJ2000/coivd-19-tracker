import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CountrymodelPageRoutingModule } from './countrymodel-routing.module';

import { CountrymodelPage } from './countrymodel.page';
import {ReversePipe} from './reverse'


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CountrymodelPageRoutingModule,
    
  ],
  declarations: [CountrymodelPage,ReversePipe,]
})
export class CountrymodelPageModule {}
