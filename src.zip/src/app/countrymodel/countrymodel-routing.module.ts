import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CountrymodelPage } from './countrymodel.page';

const routes: Routes = [
  {
    path: '',
    component: CountrymodelPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CountrymodelPageRoutingModule {}
